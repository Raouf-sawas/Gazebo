# gym_ur5 version
VERSION = '0.0.1'